/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cba.kafka;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author hemanthurs
 */
public class KafkaMessageConstruct 
{
    private static final Logger log = Logger.getLogger("KafkaMessageConstruct");
    
    private final Properties simulationDataProperties = new Properties();
    //Representation of the Root HTTP TAG    
    private String xmlDataFile =null;
    
    private String[] event_id = null;
    private String timeStampFormat = null;
    private static SimpleDateFormat sdf = null;
    private String model_name = "I09N";
    private String model_version = "0.11.2";
    private String event_name = "INTEGRATION_REQUEST";
    private String event_data_classification = "Restricted";
    private String dev_gen_hostname = "kibana.flare.prod";
    private String user_name = "someone";
    private String user_group = "csirt";
    private String user_email_primary = "someone@cba.com.au";
    private String user_phone_mobile = "614123456789";
    private String user_sip_address = "stiger@hipchat.cba.com.au";
    private String integration_action = "CONTEXTUAL_REQUEST";
    private String integration_code = "99";
    private String integration_id = "INT_99_20160229114035472";
    private String integration_request = "MALWARE_ANALYSIS";
    private String model_name_record = "M05E";
    private String model_version_record = "0.14.1";
    private String malware_action_record = "blocked";
    private String malware_source_type_record = "IPS";
    private String[] file_hash = null;
    private String integration_response_code = "EMPTY";
    private String integration_response = "EMPTY";
    private String [] integration_tag = null;
    private String integration_target = "phantom.pos";
    private boolean integration_is_action = true;
    private boolean integration_is_response = false;
    
    
           
    public KafkaMessageConstruct(String xmlFile) 
    {
        this.xmlDataFile = xmlFile;
    }
    
    
    public void setUp()
    {
        try(FileInputStream fis = new FileInputStream(xmlDataFile))
        {
            simulationDataProperties.loadFromXML(fis);
            log.info("Simualtion data loaded from file '"+xmlDataFile+"'");
            
        } catch(IOException ioe){
            log.log(Level.SEVERE, "Error reading simulation data file '"+xmlDataFile+"' : "+ioe, ioe);
            log.log(Level.SEVERE, "Terminating application now.");
            System.exit(0);
        }
        
        try {
            timeStampFormat = simulationDataProperties.getProperty("event_ts").trim();
            sdf = new SimpleDateFormat(timeStampFormat);
            
            
            event_id = simulationDataProperties.getProperty("event_id").trim().split(",");
            integration_tag = simulationDataProperties.getProperty("integration_tag").trim().split(",");
            file_hash = simulationDataProperties.getProperty("file_hash").trim().split(",");
                
        }catch (Exception ex) {
            Logger.getLogger(KafkaMessageConstruct.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
    
    
    public String generateEvent() {
        
        timeStampFormat = sdf.format(new Date());
        String levent_id = event_id[getRandomNumber(event_id.length)].trim();
        String lintegration_tag = integration_tag[getRandomNumber(integration_tag.length)].trim();
        String l_hash = file_hash[getRandomNumber(file_hash.length)].trim();
        
        
        
        final Object params[] = new Object[]{
        model_name,
        model_version,
        levent_id,    
        timeStampFormat,
        event_name,
        event_data_classification,        
        dev_gen_hostname,
        user_name,
        user_group,
        user_email_primary,
        user_phone_mobile,
        user_sip_address,
        integration_action,
        integration_code,
        integration_id,
        integration_request,
        model_name_record,
        model_version_record,
        levent_id,
        timeStampFormat,
        malware_action_record,
        malware_source_type_record,
        l_hash,
        integration_response_code,
        integration_response,
        lintegration_tag,
        integration_target,
        integration_is_action,
        integration_is_response
        };
        
        return MessageFormat.format(EVENT_TEMPLATE, params);
    
    }
    
    
    private static int getRandomNumber(int maxValue)
    {
         return 0 + (int)(Math.random() * maxValue); 
    }
    
    private static final String EVENT_TEMPLATE = 
        "'{'  \n"  +
             "\"model_name\":\"{0}\",\n" +
              "\"model_version\":\"{1}\",\n" +
              "\"event_id\":\"{2}\",\n" +
              "\"event_ts\":\"{3}\",\n" +
              "\"event_name\":\"{4}\",\n" +
              "\"event_data_classification\":\"{5}\",\n" +
              "\"dev_gen_hostname\":\"{6}\",\n" +
              "\"user_name\":\"{7}\",\n" +
              "\"user_group\":\"{8}\",\n" +
              "\"user_email_primary\":\"{9}\",\n" +
              "\"user_phone_mobile\":\"{10}\",\n" +
              "\"user_sip_address\":\"{11}\",\n" +
              "\"integration_action\":\"{12}\",\n" +
              "\"integration_code\":\"{13}\",\n" +
              "\"integration_id\":\"{14}\",\n" +
              "\"integration_request\":\"{15}\",\n" +
              "\"integration_parameters\":    \'{'\n" +
              "         \"BQ8HBgsLDgwFCQwPBAoCDA\":    \'{'\n" +
                        "           \"model_name\":\"{16}\",\n" +
                        "           \"model_version\":\"{17}\", \n" +
                        "           \"event_id\":\"{18}\", \n" +
                        "           \"event_ts\":\"{19}\", \n" +
                        "           \"malware_action\":\"{20}\", \n" +
                        "           \"malware_source_type\":\"{21}\", \n" +
                        "           \"file_hash\":\"{22}\" \n" +
              "         \'}' \n" +
            "  \'}', \n" +
            "\"integration_response_code\":\"{23}\",\n" +
            "\"integration_response\":\"{24}\",\n" +
            "\"integration_tag\":\"{25}\",\n" +
            "\"integration_target\":\"{26}\",\n" +
            "\"integration_is_action\":\"{27}\",\n" +
            "\"integration_is_response\":\"{28}\"\n" +
        "'}'";
}
