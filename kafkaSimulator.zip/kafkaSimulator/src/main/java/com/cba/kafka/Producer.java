package com.cba.kafka;

import com.google.common.io.Resources;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class Producer {

    public static void main(String[] args) throws IOException {
        // set up the producer
        KafkaProducer<String, String> producer;
        try (InputStream props = Resources.getResource("producer.props").openStream()) {
            Properties properties = new Properties();
            properties.load(props);
            producer = new KafkaProducer<>(properties);
        }

        KafkaMessageConstruct kafkaconstruct = new KafkaMessageConstruct(args[1]);
        kafkaconstruct.setUp();
        
        
        
        
        KafkaMessageFormat kafkamessage = new KafkaMessageFormat();
        kafkamessage.setD04e_id("L898482.au.cbainet.com");
        kafkamessage.setEvent_id("vytxeTZskVKR7C7WgdSP3d");
        kafkamessage.setF08s_name("Wizard.EXE");
        kafkamessage.setF08s_path("C:\\\\Windows\\\\System32");
        kafkamessage.setI09n_action("Malware Analysis");
        kafkamessage.setI09n_action_event(true);
        kafkamessage.setI09n_code("MALWARE_ANALYSIS");
        kafkamessage.setI09n_id(1);
        kafkamessage.setI09n_request("Malware Analysis");
        kafkamessage.setI09n_tag("vytxeTZskVKR7C7WgdSP3d");
        kafkamessage.setMD5("0003C07AF5665937CF26705A9692190C");

       
        
        try {
            
            while(true){
            String testmessage = kafkaconstruct.generateEvent();
            ProducerRecord<String, String> record1 = new ProducerRecord<>("request-topic", testmessage);
            Thread.sleep(2000); //every 2 seconds
            producer.send(record1);
            producer.flush();
            System.out.println("Sent msg " + record1.toString());
            }
        } catch (Throwable throwable) {
            System.out.printf("%s", throwable.getStackTrace());
        } finally {
            producer.close();
        }

    }
}
