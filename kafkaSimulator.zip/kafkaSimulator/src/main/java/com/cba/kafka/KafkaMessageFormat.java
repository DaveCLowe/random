/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cba.kafka;

import java.util.Hashtable;

/**
 *
 * @author hemanthurs
 */
public class KafkaMessageFormat {

    private String i09n_action = null;
    private String i09n_code = null;
    private int i09n_id = 0;
    private String MD5 = null;
    private String event_id = null;
    private String d04e_id = null;
    private String f08s_name = null;
    private String f08s_path = null;
    private String i09n_request = null;
    private String i09n_tag = null;
    private boolean i09n_action_event = false;

    public KafkaMessageFormat() {
    }

    @Override
    public String toString() {
        return "KafkaMessageFormat{" + "i09n_action=" + i09n_action + ", i09n_code=" + i09n_code + ", i09n_id=" + i09n_id + ", MD5=" + MD5 + ", event_id=" + event_id + ", d04e_id=" + d04e_id + ", f08s_name=" + f08s_name + ", f08s_path=" + f08s_path + ", i09n_request=" + i09n_request + ", i09n_tag=" + i09n_tag + ", i09n_action_event=" + i09n_action_event + '}';
    }

    public void setI09n_action(String i09n_action) {
        this.i09n_action = i09n_action;
    }

    public void setI09n_code(String i09n_code) {
        this.i09n_code = i09n_code;
    }

    public void setI09n_id(int i09n_id) {
        this.i09n_id = i09n_id;
    }

    public void setMD5(String MD5) {
        this.MD5 = MD5;
    }

    public void setEvent_id(String event_id) {
        this.event_id = event_id;
    }

    public void setD04e_id(String d04e_id) {
        this.d04e_id = d04e_id;
    }

    public void setF08s_name(String f08s_name) {
        this.f08s_name = f08s_name;
    }

    public void setF08s_path(String f08s_path) {
        this.f08s_path = f08s_path;
    }

    public void setI09n_request(String i09n_request) {
        this.i09n_request = i09n_request;
    }

    public void setI09n_tag(String i09n_tag) {
        this.i09n_tag = i09n_tag;
    }

    public void setI09n_action_event(boolean i09n_action_event) {
        this.i09n_action_event = i09n_action_event;
    }

    public String getI09n_action() {
        return i09n_action;
    }

    public String getI09n_code() {
        return i09n_code;
    }

    public int getI09n_id() {
        return i09n_id;
    }

    public String getMD5() {
        return MD5;
    }

    public String getEvent_id() {
        return event_id;
    }

    public String getD04e_id() {
        return d04e_id;
    }

    public String getF08s_name() {
        return f08s_name;
    }

    public String getF08s_path() {
        return f08s_path;
    }

    public String getI09n_request() {
        return i09n_request;
    }

    public String getI09n_tag() {
        return i09n_tag;
    }

    public boolean isI09n_action_event() {
        return i09n_action_event;
    }

}
